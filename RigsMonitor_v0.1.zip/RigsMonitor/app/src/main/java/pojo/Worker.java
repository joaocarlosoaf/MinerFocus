package pojo;

import java.util.ArrayList;

/**
 * Created by joaoc on 10/11/2017.
 * Classe worker é reponsável por armazenar informações de cada RIG
 */

public class Worker {

    public String id;
    public String hashrate;
    public ArrayList<String> avghashrate;

    public Worker(String id, String idValue, String hashrate,
                  String hashrateValue, ArrayList<String> avghashrate){

        this.id = id;
        this.hashrate = hashrate;
        this.avghashrate = avghashrate;

    }


}
