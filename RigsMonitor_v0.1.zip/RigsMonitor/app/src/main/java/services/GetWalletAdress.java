package services;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by joaoc on 07/01/2018.
 */

public class GetWalletAdress {


    public ArrayList<String> getNanopoolWalletAdress(Context context){

        FileManipulator fileManipulator = new FileManipulator();
        String aux = fileManipulator.readFile(context);
        ArrayList<String> nanopool = new ArrayList<>();

        int index;

        while (aux.length() > 1){

            index = aux.indexOf("nanopool");
            nanopool.add(aux.substring(index+11,aux.indexOf(';')));
            aux = aux.substring(aux.indexOf(';')+1,aux.length());

        }

        return nanopool;
    }

    public ArrayList<String> getEtherminerWalletAdress(Context context){

        FileManipulator fileManipulator = new FileManipulator();
        String aux = fileManipulator.readFile(context);
        ArrayList<String> etherminer = new ArrayList<>();

        int index;

        while (aux.length() > 1){

            index = aux.indexOf("ethermine");
            etherminer.add(aux.substring(index+9,aux.indexOf(';')-1));
            aux = aux.substring(aux.indexOf(';')+1,aux.length());

        }

        return etherminer;
    }

}
