package services;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

/**
 * Created by joaoc on 28/10/2017.
 */

public class FileManipulator {

    private final String FILE_NAME = "monitorRIGs.oaf";
    private final String DIR_NAME      = "appRIG";

    public boolean isDirExist(Context context){

        File file = context.getDir(DIR_NAME, Context.MODE_PRIVATE);

        if(file.exists()) return true;

        else return file.mkdir();

    }

    public boolean isFileExist(){

        return false;
    }

    public boolean writeFile(Context context, String name, String value){


        try {
            String data;

            if(readFile(context).length()>1)
                data = readFile(context);
            else
                data = "";

            //data = "";
            data += name+":"+value+";";
            FileOutputStream fos = context.getApplicationContext().openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            fos.write(data.getBytes());
            fos.close();
            return true;
        } catch (FileNotFoundException e) {
            Log.d("ERRO - ","FileManipulator.writeFile::FileNotFoundException");
            e.printStackTrace();
        } catch (IOException e) {
            Log.d("ERRO - ","FileManipulator.writeFile::IOException");
            e.printStackTrace();
        }
        return false;
    }

    public String readFile(Context context){

        //Recupera o arquivo passando o caminho getFileDir() (Que busca a pasta da aplicação) e FILE_NAME (Nome do arquivo)
        File file = new File(context.getFilesDir(), FILE_NAME);
        StringBuilder text = new StringBuilder();
        Log.d("TESTE - FileManipulator", "readFile() -- context.getApplicationInfo().dataDir =  "+ context.getApplicationInfo().dataDir);
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
            br.close();
            Log.d("SAIDA - FileManipulator", "readFile() -- data =  "+ text.toString());
            return text.toString();
        }
        catch (IOException e) {
            //You'll need to add proper error handling here
        }

        return "";
    }

}
