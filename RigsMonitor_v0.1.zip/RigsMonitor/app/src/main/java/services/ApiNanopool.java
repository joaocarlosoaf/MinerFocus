package services;

import android.content.Context;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import interfaces.ApiNanopoolInterface;

/**
 * Created by joaoc on 09/01/2018.
 */

public class ApiNanopool {

    private static final String URL_WORKERS_LAST_REPORTED_HASHRATE = "https://api.nanopool.org/v1/eth/reportedhashrates/";
    private static final String URL_CALCULATE_HASHRATE = "https://api.nanopool.org/v1/eth/approximated_earnings/";
    private Context context;
    static private String jsonString;


    public String get

    public String getWorkersLastReportedHashrate(Context context, final ApiNanopoolInterface apiNanopoolInterface, final String wallet){

        this.context = context;

        Log.d("startDownloadJson::",URL_WORKERS_LAST_REPORTED_HASHRATE + wallet);

        RequestQueue rQueue = Volley.newRequestQueue(this.context);

        StringRequest stringRequest = new StringRequest(URL_WORKERS_LAST_REPORTED_HASHRATE + wallet, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                jsonString = response;
                Log.d("onResponse::",jsonString);
                apiNanopoolInterface.getWorkersLastReportedHashrate(jsonString, wallet);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ApiNanopool::onErrorRes","erro:"+error.getMessage());
            }
        });

        rQueue.add(stringRequest);
        return jsonString;

    }

    public String getHashRateCalculator(Context context, final ApiNanopoolInterface apiNanopoolInterface, final String wallet, final String hashrate){

        this.context = context;

        Log.d("startDownloadJson::",URL_CALCULATE_HASHRATE + hashrate);

        RequestQueue rQueue = Volley.newRequestQueue(this.context);

        StringRequest stringRequest = new StringRequest(URL_CALCULATE_HASHRATE + hashrate, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                jsonString = response;
                Log.d("onResponse::",jsonString);
                apiNanopoolInterface.getHashRateCalculator(jsonString, wallet, hashrate);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("ApiNanopool::onErrorRes","erro:"+error.getMessage());
            }
        });

        rQueue.add(stringRequest);
        return jsonString;

    }

}
