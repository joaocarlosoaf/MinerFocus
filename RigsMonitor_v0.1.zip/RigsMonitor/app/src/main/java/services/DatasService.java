package services;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import interfaces.DataServiceInterface;
import pojo.Data;
import pojo.Worker;

/**
 * Created by joaoc on 17/11/2017.
 * Classe responsável por baixar e montar o JsonObject e retornar Datas(um array de Data) usando Interface
 * "https://api.nanopool.org/v1/eth/user/0xf14c49c427f3006f445ca6c064f5829cdf896170"
 */

public class DatasService {

    private Data data;
    private List<Data>  datas;
    private ArrayList<String> avghashrate;
    private ArrayList<Worker> workers;
    private ProgressDialog progressDialog;
    private String stringJson = "";
    private DataServiceInterface dataServiceTaskInterface;
    private Context context;
    private String jsonString;

    public DatasService(Context context, DataServiceInterface dataServiceTaskInterface, ProgressDialog progressDialog){

        this.context = context;
        this.dataServiceTaskInterface = dataServiceTaskInterface;
        this.progressDialog = progressDialog;

    }

    // Método responsável por iniciar as operações de download, converter para string, criar objeto DATA
    // e retornar o Obejeto DATA para a classe TelaRelatorioFragment atraves da Interface DataServiceInterface
    public void start(){

        downloadAndCreateDatas("https://api.nanopool.org/v1/eth/user/0xf14c49c427f3006f445ca6c064f5829cdf896170");

    }

    // Recebe JSON em formato String e atribui os valores do JSON para o objeto DATA
    private Data createListDatas(String json){
        try {
            JSONObject jsonObject = new JSONObject(json);

            Log.d("Indice::Comprimento",""+jsonObject.length());
            Log.d("SAIDA::data",""+jsonObject.getString("data"));


            avghashrate = new ArrayList<>();
            /*
            avghashrate.add(jsonObject.getString("h1"));
            avghashrate.add(jsonObject.getString("h3"));
            avghashrate.add(jsonObject.getString("h6"));
            avghashrate.add(jsonObject.getString("h12"));
            avghashrate.add(jsonObject.getString("h24"));
            */

            JSONObject jsonObjectData= jsonObject.getJSONObject("data");

            JSONObject jsonObjectAVGHashRate = jsonObjectData.getJSONObject("avgHashrate");

            Log.d("SAIDA::jsonArrayData",""+jsonObjectData.getString("balance"));

            avghashrate.add(jsonObjectAVGHashRate.getString("h24"));
            avghashrate.add(jsonObjectAVGHashRate.getString("h12"));
            avghashrate.add(jsonObjectAVGHashRate.getString("h6"));
            avghashrate.add(jsonObjectAVGHashRate.getString("h3"));
            avghashrate.add(jsonObjectAVGHashRate.getString("h1"));



            Log.d("SAIDA::jsonObjectAVGH",""+jsonObjectAVGHashRate.getString("h24"));

            data = new Data(jsonObjectData.getString("account"),
                    jsonObjectData.getString("balance"),
                    jsonObjectData.getString("hashrate"),
                    avghashrate,
                    workers);

            /*
            for(int i = 0 ; i < jsonArray.length() ; i++){
                avghashrate.add(jsonArray.getString(i));
                Log.d("SAIDA::jsonArray.length",jsonArray.getString(i)+jsonArray.length());
            }


            data = new Data(jsonObject.getString("account"),
                            jsonObject.getString("balance"),
                            jsonObject.getString("hashrate"),
                            avghashrate,
                            workers);
         */

            return data;
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;

    }

    // Método responsável por baixar o conteudo JSON no formato String
    private String downloadAndCreateDatas(String url){

        Log.d("startDownloadJson::",url);

        RequestQueue rQueue = Volley.newRequestQueue(context);

        progressDialog.setMessage("Carregando....");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                jsonString = response;
                Log.d("onResponse::",jsonString);
                // Atribuindo o objeto Data ao método da Interface DataServiceInterface
                dataServiceTaskInterface.getArrayDatas(createListDatas(jsonString));
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("JSOIN::onErrorResponse","erro:"+error.getMessage());
                jsonString = "Error::onErrorResponse";
                progressDialog.dismiss();
            }
        });

        rQueue.add(stringRequest);
        return jsonString;
    }

}
