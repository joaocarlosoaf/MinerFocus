package interfaces;

import pojo.CalculatorDataWorker;

/**
 * Created by joaoc on 06/01/2018.
 */

public interface CalculatorServiceInterface {

    public void getCalculatorDataWorker(CalculatorDataWorker calculatorDataWorker);
}
