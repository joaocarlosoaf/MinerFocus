package interfaces;

/**
 * Created by joaoc on 09/01/2018.
 */

public interface ApiNanopoolInterface {

    public void getWorkersLastReportedHashrate(String json, String wallet);
    public void getHashRateCalculator(String jsoin, String wallet, String hashrate);

}
