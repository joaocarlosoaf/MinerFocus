package interfaces;

import java.util.ArrayList;

import pojo.Data;

/**
 * Created by joaoc on 07/12/2017.
 */

public interface DataServiceInterface {

    public void getArrayDatas(Data data);

}
