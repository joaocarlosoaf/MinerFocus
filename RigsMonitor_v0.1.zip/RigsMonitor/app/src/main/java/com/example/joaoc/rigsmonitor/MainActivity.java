package com.example.joaoc.rigsmonitor;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;

import adapters.ViewPagerAdapter;
import fragments.TelaCalculadoraFragment;
import fragments.TelaRelatorioFragment;
import services.FileManipulator;
import services.GetWalletAdress;

public class MainActivity extends AppCompatActivity{

    private ViewPagerAdapter adapter;
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private FileManipulator fileManipulator = new FileManipulator();
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //fileManipulator.writeFile(this,"");
        Toolbar toolbar= (Toolbar) findViewById(R.id.toolbar_telarelatorio);
        setSupportActionBar(toolbar);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);

        //teste();

    }

    private void teste(){

        fileManipulator.writeFile(this,"nanopool","0xcb69622c0efdd70c579799e53f7b9f869eb6d79c");
        fileManipulator.readFile(this);

        GetWalletAdress getWalletAdress = new GetWalletAdress();
        ArrayList<String> nanopool = getWalletAdress.getNanopoolWalletAdress(this);

        for(int i = 0 ; i < nanopool.size() ; i++){

            Log.d("teste", "Carteira "+i+": "+nanopool.get(i));

        }

    }

    private void setupViewPager(ViewPager viewPager) {
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.addFragment(new TelaRelatorioFragment(), "Minerando");
        adapter.addFragment(new TelaCalculadoraFragment(),"Calculadora");
        //adapter.addFragment(new ThreeFragment(), "THREE");
        viewPager.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        Log.d("AQUI::TelaRelatFrag::","onCreateOptionsMenu");
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_tela_relatorio, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_refresh:

                Log.d("SAIDA","viewPager.getCurrentItem()" + viewPager.getCurrentItem());

                Fragment currentFragment = adapter.getItem(viewPager.getCurrentItem());
                if (viewPager.getCurrentItem() == 0){
                    TelaRelatorioFragment telaRelatorioFragment = (TelaRelatorioFragment) currentFragment;
                    telaRelatorioFragment.showDatas();
                }
                if (viewPager.getCurrentItem() == 1){

                    TelaCalculadoraFragment telaCalculadoraFragment = (TelaCalculadoraFragment) currentFragment;
                    telaCalculadoraFragment.refreshFragment();
                }


                return true;

            case R.id.action_insert_wallet:
                getAlertInputDialog();
                return true;

            case R.id.action_onoff_notification:

                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
        finish();
    }

    //Método responsável por criar e invocar o AlertDialog
    private void getAlertInputDialog(){

        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View alertBoxView = layoutInflater.inflate(R.layout.alert_input_pincode_box,null);
        AlertDialog.Builder alertDialogBuilderUserInput = new AlertDialog.Builder(this);
        alertDialogBuilderUserInput.setView(alertBoxView);
        Resources res = getResources();

        final EditText userInputDialogPINCode = (EditText) alertBoxView.findViewById(R.id.userInputDialog);

        context = this;
        alertDialogBuilderUserInput
                .setCancelable(false)
                .setPositiveButton(res.getText(R.string.alert_input_pincode_textinput_btn_send), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        fileManipulator.writeFile(context,"nanopool",userInputDialogPINCode.getText().toString());

                    }
                })
                .setNegativeButton(res.getText(R.string.alert_input_pincode_textinput_btn_cancelar), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which){}
                });
        AlertDialog alertDialog = alertDialogBuilderUserInput.create();
        alertDialog.show();

    }

}
